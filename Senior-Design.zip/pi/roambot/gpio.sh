#!/bin/bash
# chmod +x gpio.sh

sudo ~/roambot/myenv/bin/python3 ~/roambot/gpio_test.py
