#!/bin/bash
# chmod +x serial.sh

sudo ~/roambot/myenv/bin/python3 ~/roambot/serial_test.py
